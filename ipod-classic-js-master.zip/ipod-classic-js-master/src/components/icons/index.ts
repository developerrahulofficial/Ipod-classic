export { default as SadMacIcon } from './SadMacIcon';
