export type WheelButtonProps = {
  margin?: string;
  top?: string;
  bottom?: string;
  left?: string;
  right?: string;
};
